cd $(dirname $0)
FilePath=`pwd`
${FilePath}/randomPlayer
